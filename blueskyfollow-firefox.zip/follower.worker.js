"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const worker_threads_1 = require("worker_threads");
const api_1 = require("@atproto/api");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
async function followUsers() {
    const agent = new api_1.BskyAgent({
        service: 'https://bsky.social'
    });
    let paused = false;
    let followInterval = 2000; // Start with 2 second interval
    const minInterval = 1000;
    const maxInterval = 10000;
    let consecutiveSuccesses = 0;
    let consecutiveFailures = 0;
    // Handle pause/resume signals from main thread
    worker_threads_1.parentPort?.on('message', (message) => {
        if (message.type === 'pause') {
            paused = true;
            console.log('Worker paused due to rate limit');
        }
        else if (message.type === 'resume') {
            paused = false;
            console.log('Worker resumed');
        }
    });
    // Login using credentials from parent
    worker_threads_1.parentPort?.once('message', async (credentials) => {
        if (credentials.type === 'credentials') {
            try {
                await agent.login(credentials);
                while (true) {
                    // Wait if paused
                    while (paused) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                    // Get next task from parent
                    worker_threads_1.parentPort?.postMessage({ type: 'ready' });
                    const task = await new Promise((resolve) => {
                        worker_threads_1.parentPort?.once('message', (message) => {
                            if (message.type === 'task')
                                resolve(message.task);
                        });
                    });
                    try {
                        // Wait based on dynamic timing
                        await new Promise(resolve => setTimeout(resolve, followInterval));
                        // Attempt follow
                        await agent.follow(task.did);
                        consecutiveSuccesses++;
                        consecutiveFailures = 0;
                        // Adjust timing on success
                        if (consecutiveSuccesses >= 5) {
                            followInterval = Math.max(minInterval, followInterval * 0.8);
                            consecutiveSuccesses = 0;
                        }
                        worker_threads_1.parentPort?.postMessage({
                            type: 'result',
                            success: true,
                            handle: task.handle
                        });
                    }
                    catch (err) {
                        consecutiveFailures++;
                        consecutiveSuccesses = 0;
                        // Exponential backoff on failure
                        followInterval = Math.min(maxInterval, followInterval * (1 + (consecutiveFailures * 0.5)));
                        const isRateLimit = err instanceof Error && err.message.includes('Rate Limit');
                        const alreadyFollowing = err instanceof Error && err.message.includes('already following');
                        worker_threads_1.parentPort?.postMessage({
                            type: 'result',
                            success: alreadyFollowing,
                            error: err instanceof Error ? err.message : 'Unknown error',
                            isRateLimit,
                            handle: task.handle
                        });
                    }
                }
            }
            catch (err) {
                worker_threads_1.parentPort?.postMessage({
                    type: 'error',
                    error: err instanceof Error ? err.message : 'Failed to login'
                });
            }
        }
    });
}
followUsers();
