"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const worker_threads_1 = require("worker_threads");
const api_1 = require("@atproto/api");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const HEALTH_CHECK_INTERVAL = 2000; // Check every 2 seconds
async function monitorApiHealth() {
    const agent = new api_1.BskyAgent({
        service: 'https://bsky.social'
    });
    // Login using credentials from parent thread
    worker_threads_1.parentPort?.once('message', async (credentials) => {
        try {
            await agent.login(credentials);
            while (true) {
                try {
                    // Perform lightweight health check
                    const response = await agent.getProfile({ actor: agent.session?.did || '' });
                    const headers = response.headers;
                    const status = {
                        healthy: true,
                        remaining: parseInt(headers['x-ratelimit-remaining'] || '0'),
                        reset: parseInt(headers['x-ratelimit-reset'] || '0'),
                        timestamp: Date.now()
                    };
                    worker_threads_1.parentPort?.postMessage(status);
                }
                catch (err) {
                    const isRateLimit = err instanceof Error && err.message.includes('Rate Limit');
                    worker_threads_1.parentPort?.postMessage({
                        healthy: false,
                        isRateLimit,
                        error: err instanceof Error ? err.message : 'Unknown error',
                        timestamp: Date.now()
                    });
                }
                // Wait before next check
                await new Promise(resolve => setTimeout(resolve, HEALTH_CHECK_INTERVAL));
            }
        }
        catch (err) {
            worker_threads_1.parentPort?.postMessage({
                healthy: false,
                error: err instanceof Error ? err.message : 'Failed to login',
                timestamp: Date.now()
            });
        }
    });
}
monitorApiHealth();
